import Employe from "./Employe"

function App() {


  return (
    <>
    <Employe/>
    </>
  )
}

export default App

import React, { use, useState } from 'react'

function Employe() {
  const [employees, setEmployee] = useState([
    { empid: 1, name: 'Ajay', salary: 38000, job: 'Accountant', deparment: 'HMCT', status: 'Inactive' },
    { empid: 2, name: 'Jugraj', salary: 45000, job: 'Developer', deparment: 'CSE', status: 'Inactive' },
    { empid: 3, name: 'Arjun', salary: 4000, job: 'Manager', deparment: 'CSE', status: 'Active' },
    { empid: 4, name: 'Arun', salary: 44000, job: 'Developer', deparment: 'CSE', status: 'Inactive' },
    { empid: 5, name: 'Simran', salary: 2000, job: 'HR', deparment: 'Management', status: 'Inactive' },
    { empid: 6, name: 'Neha', salary: 60000, job: 'Project Manager', deparment: 'IT', status: 'Inactive' },
    { empid: 7, name: 'Rohit', salary: 3000, job: 'Designer', deparment: 'UI/UX', status: 'Inactive' },
    { empid: 8, name: 'Pooja', salary: 42000, job: 'Data Analyst', deparment: 'Analytics', status: 'Inactive' },
    { empid: 9, name: 'Manish', salary: 28000, job: 'Support Engineer', deparment: 'Tech Support', status: 'Inactive' },
    { empid: 10, name: 'Karan', salary: 75000, job: 'Team Lead', deparment: 'IT', status: 'Active' },
  ]);

 function Changestatus(id){
   setEmployee(prev=>{
   return prev.map(emp=>{
    return emp.empid ===id?
    {...emp,status:emp.status==='Active'?'Inactive':"Active"}:emp;

    })
   })
 }


  

  return (
    <>
    <table className='table table-bordered table-hover text-center allign-middle' >
        <tr>
            <th>Empid</th>
            <th>Name</th>
            <th>Salary</th>
            <th>Job</th>
            <th>Department</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
       {employees.map((employee,index)=>(
         <tr key={index}>
            <td>{employee.empid}</td>
            <td>{employee.name}</td>
            <td>{employee.salary}</td>
            <td>{employee.job}</td>
            <td>{employee.deparment}</td>
            <td><span className={`badge ${employee.salary>4000?"text-bg-success":"text-bg-danger"}`}>{employee.salary>4000?"Online":"Offline"}</span></td>
            <td ><button type="button" class={`${employee.status=='Inactive'? 'btn btn-danger bg bg-danger':'btn btn-primary bg bg-success'}`}onClick={() => Changestatus(employee.empid)}
>
              {employee.status}</button></td>
        </tr>
       
       ))}
        
       
    </table>
    
    </>
  )
}

export default Employe

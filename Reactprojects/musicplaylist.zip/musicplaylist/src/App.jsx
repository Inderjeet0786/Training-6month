import Playlist from "./Components/Playlist"

function App() {


  return (
    <>
  <Playlist/>    
    </>
  )
}

export default App

import React from 'react'

function Component2() {
  return (
    <>
      
    </>
  )
}

export default Component2

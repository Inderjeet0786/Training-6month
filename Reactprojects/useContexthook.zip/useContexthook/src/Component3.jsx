import React, { useContext } from 'react'
import { ThemeContext } from './App'

function Component3() {
    const {theme,ChangeTheme} = useContext(ThemeContext)
  return (
    <>
      
    </>
  )
}

export default Component3

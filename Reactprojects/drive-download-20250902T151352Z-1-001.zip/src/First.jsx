import Second from "./Second";

export default function First(){
    return(
        <>
                {/* <h1>This is First com</h1> */}
                <Second/>
        </>

    )
}
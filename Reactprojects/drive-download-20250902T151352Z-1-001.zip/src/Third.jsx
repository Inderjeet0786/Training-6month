
import { data1,data2 } from "./App"
import Forth from "./Forth";

export default function Third(){
        
        
    return(
        <>
                {/* <h1>This is Third com </h1> */}
                <Forth/>
        </>

    )
}
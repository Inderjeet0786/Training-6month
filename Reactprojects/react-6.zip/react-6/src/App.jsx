import Header from './assets/Components/Header'
import './App.css'
import Footer from './assets/Components/Footer'
import Body from './assets/Components/Body'

function App() {
 

  return (
    <>
 <Header/>
 <Body/>
 <Footer/>
    </>
  )
}

export default App

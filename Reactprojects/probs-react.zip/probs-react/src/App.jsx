import Component1 from "./Component1"



function App() {


  return (
    <>
    <Component1/>
    </>
  )
}

export default App

import Forth from "./Forth";
function Third() {
  return (
    <>
     <Forth/>
    </>
  )
}

export default Third;

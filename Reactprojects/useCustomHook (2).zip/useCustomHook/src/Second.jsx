import Third from "./Third"
export default function Second(){
  return(
    <>
   <Third/>
    </>
  )
}
